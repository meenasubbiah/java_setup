package org.meena.learning.rsim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RsimApplication {

	public static void main(String[] args) {
		SpringApplication.run(RsimApplication.class, args);
	}

}
