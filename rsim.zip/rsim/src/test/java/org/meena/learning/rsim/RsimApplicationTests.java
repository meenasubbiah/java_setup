package org.meena.learning.rsim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsimApplicationTests {

	@Test
	void contextLoads() {
	}

}
